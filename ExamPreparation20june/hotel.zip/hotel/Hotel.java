package ExamPreparation20june.hotel;

import java.util.ArrayList;
import java.util.List;

public class Hotel {
    List<Person> people;
    private String name;
    private int capacity;

    public Hotel(String name, int capacity) {
        this.people = new ArrayList<>();
        this.name = name;
        this.capacity = capacity;
    }

    public void add(Person person) {
        if (this.people.size() + 1 < this.capacity) {
            people.add(person);
        }
    }

    public boolean remove(String name) {
        for (Person person : people) {
            if (name.equals(person.getName())) {
                this.people.remove(person);
                return true;
            }
        }
        return false;
    }

    public Person getPerson(String name, String hometown) {
        List<Person> personList = new ArrayList<>();
        for (Person person : people) {
            if (name.equals(person.getName()) && hometown.equals(person.getHometown())) {
                return person;
            }
        }
        return null;
    }

    public int getCount() {
        return this.people.size();
    }

    public String getStatistics() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("The people in the ExamPreparation20june.hotel %s are:%n", this.name));
        this.people.forEach(person -> sb.append(person.toString()));
        return sb.toString();
    }
}
